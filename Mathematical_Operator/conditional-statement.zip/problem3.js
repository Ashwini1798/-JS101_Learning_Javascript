//Problem 3: Given 2 numbers a and b print which is greater or "both equal".

let a=10;
let b=20;

if (a>b){
  console.log(a,"is greater");
}else if(b>a){
  console.log(b,"is greater");
}else{
  console.log("both are equal");
}