//Problem 2: If a person is allowed to drive in India print "Apply for a license" or "NA".

let age=18;
if (age>=18){
  console.log("Apply for a license");
}else{
  console.log("NA")
}